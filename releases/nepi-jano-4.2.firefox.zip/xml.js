window.location = document.querySelector('webUrl').textContent;
